#define BITPIT_VERSION "1.6.0-devel"
